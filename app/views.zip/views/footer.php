<footer class="bg-dark text-white esconde-print" style="margin-top: 5vh;">
    <div class="container">
        <div class="row  p-4">
            <div class="col-12 col-md-6">
                <small>
                    Sitema de Pedidos
                </small>
            </div>
            <div class="col-12 col-md-6">
                <small>
                    &copy; 2020 - <?= date('Y') ?>
                </small>
            </div>
        </div>
        <hr style="border: 1px solid #fff;">    
        <div class="row">
            <div class="col text-center">
                <p>
                    Desenvolvido por <a href="https://wildarte.com.br">WildArte</a>
                </p>
            </div>
        </div>
    </div>
</footer>