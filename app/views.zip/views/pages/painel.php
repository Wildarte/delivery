<div class="container">
    <div class="row">
        <div class="col-12">
            <header>
                <h1>
                    Painel da Administração
                </h1>
            </header>
        </div>
    </div>
</div>