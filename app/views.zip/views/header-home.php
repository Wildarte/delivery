<nav class="header-home text-center fixed-top shadow">
    <img src="https://cdn.pixabay.com/photo/2016/09/13/18/38/silverware-1667988_960_720.png" alt="" srcset="">
</nav>